use crate::domains::{AtomDomain, SeriesDomain};
use crate::domains::{LazyFrameDomain, Margin};
use crate::error::ErrorVariant::MakeMeasurement;
use crate::error::*;
use crate::measurements::make_private_lazyframe;
use crate::measures::MaxDivergence;
use crate::polars::PrivacyNamespace;
use polars::prelude::*;
use polars_plan::prelude::ProjectionOptions;

use crate::metrics::SymmetricDistance;

use super::*;

#[test]
#[cfg(not(feature = "polars-ffi"))]
fn test_select_no_margin() -> Fallible<()> {
    let lf_domain =
        LazyFrameDomain::new(vec![SeriesDomain::new("A", AtomDomain::<i32>::default())])?;

    let lf = df!("A" => &[1i32, 2, 2])?.lazy();

    let m_select = make_private_lazyframe(
        lf_domain,
        FrameDistance(SymmetricDistance),
        MaxDivergence,
        lf.clone().select(&[len().dp().noise(Some(0.))]),
        Some(1.),
        None,
    )?;

    let actual = m_select.invoke(&lf)?.collect()?;
    let expect = df!("len" => [3])?;

    assert_eq!(actual, expect);
    Ok(())
}

#[test]
#[cfg(not(feature = "polars-ffi"))]
fn test_select() -> Fallible<()> {
    let lf_domain =
        LazyFrameDomain::new(vec![SeriesDomain::new("A", AtomDomain::<i32>::default())])?
            .with_margin(Margin::select().with_max_length(10))?;

    let lf = df!("A" => &[1i32, 2, 2])?.lazy();

    let m_select = make_private_lazyframe(
        lf_domain,
        FrameDistance(SymmetricDistance),
        MaxDivergence,
        lf.clone().select(&[
            col("A").dp().sum((lit(0), lit(3)), Some(0.)),
            len().dp().noise(Some(0.)),
        ]),
        Some(1.),
        None,
    )?;

    let actual = m_select.invoke(&lf)?.collect()?;
    let expect = df!("A" => [5], "len" => [3])?;

    assert_eq!(actual, expect);
    Ok(())
}

#[test]
fn test_fail_select_invalid_expression() -> Fallible<()> {
    let lf_domain = DslPlanDomain::new(vec![SeriesDomain::new("A", AtomDomain::<i32>::default())])?;

    let lf = df!("A" => &[1i32, 2, 2])?.lazy();

    let error_variant_res = make_private_select::<_, _>(
        lf_domain,
        FrameDistance(SymmetricDistance),
        MaxDivergence,
        // this expression cannot be parsed into a measurement
        lf.select(&[col("A").sum()]).logical_plan,
        Some(1.),
    )
    .map(|_| ())
    .unwrap_err()
    .variant;

    assert_eq!(MakeMeasurement, error_variant_res);

    Ok(())
}

#[test]
fn test_private_select_rejects_noncanonical_projection_options() -> Fallible<()> {
    use std::sync::Arc;

    let lf = df!("A" => [1i32, 2])?.lazy();
    let domain = LazyFrameDomain::new(vec![SeriesDomain::new("A", AtomDomain::<i32>::default())])?
        .with_margin(Margin::select().with_max_length(2))?;
    let options = ProjectionOptions {
        should_broadcast: false,
        ..ProjectionOptions::default()
    };
    let query = LazyFrame::from(DslPlan::Select {
        input: Arc::new(lf.logical_plan.clone()),
        expr: vec![len().dp().noise(Some(1.0))],
        options,
    });
    assert!(
        make_private_lazyframe(
            domain,
            FrameDistance(SymmetricDistance),
            MaxDivergence,
            query,
            None,
            None,
        )
        .is_err()
    );
    Ok(())
}

use crate::core::Domain;
use crate::domains::{AtomDomain, LazyFrameDomain, SeriesDomain};
use crate::metrics::{FrameDistance, SymmetricDistance};
use crate::transformations::make_stable_lazyframe;

use super::*;

#[test]
fn test_make_expr_cast_string() -> Fallible<()> {
    let lf_domain = LazyFrameDomain::new(vec![SeriesDomain::new(
        "String",
        AtomDomain::<String>::default(),
    )])?;
    let lf = df!(
        "String" => &["A".to_string(), "3.14".to_string(), "1e300".to_string(), "NaN".to_string()],
    )?
    .lazy();

    let casted = lf.clone().with_columns([
        col("String").cast(DataType::Float64).alias("String_f64"),
        col("String").cast(DataType::Int64).alias("String_i64"),
        // Polars doesn't support casting a string to a boolean
        // col("String").cast(DataType::Boolean).alias("String_bool"),
    ]);
    let t_casted = make_stable_lazyframe(lf_domain, FrameDistance(SymmetricDistance), casted)?;

    let actual = t_casted.invoke(&lf)?.collect()?;
    let expected = df!(
        // repeat inputs
        "String" => &["A".to_string(), "3.14".to_string(), "1e300".to_string(), "NaN".to_string()],

        // string -> int casts can go to null and nan
        "String_f64" => &[None, Some(3.14), Some(1e300), Some(f64::NAN)],
        // No value is exactly integer, so all are None
        "String_i64" => &[None::<i64>, None, None, None],
        // non-strict casting still fails, but fails in a data-independent way
        // "String_bool" => &[],
    )?;
    assert_eq!(expected, actual);
    Ok(())
}

#[test]
fn test_make_expr_cast_f64() -> Fallible<()> {
    let lf_domain =
        LazyFrameDomain::new(vec![SeriesDomain::new("f64", AtomDomain::<f64>::default())])?;
    let lf = df!(
        "f64" => &[f64::NAN, 1., 1.0e300, -1.],
    )?
    .lazy();

    let casted = lf.clone().with_columns([
        col("f64").cast(DataType::String).alias("f64_String"),
        col("f64").cast(DataType::Int64).alias("f64_i64"),
        col("f64").cast(DataType::Boolean).alias("f64_bool"),
    ]);
    let t_casted = make_stable_lazyframe(lf_domain, FrameDistance(SymmetricDistance), casted)?;

    let actual = t_casted.invoke(&lf)?.collect()?;
    let expected = df!(
        // repeat inputs
        "f64" => &[f64::NAN, 1., 1e300, -1.],
        "f64_String" => &["NaN".to_string(), "1.0".to_string(), "1e300".to_string(), "-1.0".to_string()],
        "f64_i64" => &[None, Some(1), None, Some(-1)],
        // NaN is considered truth-y
        "f64_bool" => &[true, true, true, true],
    )?;
    assert_eq!(expected, actual);
    Ok(())
}

#[test]
fn test_make_expr_cast_int() -> Fallible<()> {
    let lf_domain =
        LazyFrameDomain::new(vec![SeriesDomain::new("i64", AtomDomain::<i64>::default())])?;
    let lf = df!(
        "i64" => &[i64::MAX, i64::MIN, 0, 1],
    )?
    .lazy();

    let casted = lf.clone().with_columns([
        col("i64").cast(DataType::String).alias("i64_String"),
        col("i64").cast(DataType::Float64).alias("i64_f64"),
        col("i64").cast(DataType::Boolean).alias("i64_bool"),
    ]);
    let t_casted = make_stable_lazyframe(lf_domain, FrameDistance(SymmetricDistance), casted)?;

    let actual = t_casted.invoke(&lf)?.collect()?;
    let expected = df!(
        // repeat inputs
        "i64" => &[i64::MAX, i64::MIN, 0, 1],
        "i64_String" => &["9223372036854775807".to_string(), "-9223372036854775808".to_string(), "0".to_string(), "1".to_string()],
        "i64_f64" => &[i64::MAX as f64, i64::MIN as f64, 0.0, 1.0],
        "i64_bool" => &[true, true, false, true],
    )?;
    assert_eq!(expected, actual);
    Ok(())
}

#[test]
fn test_make_expr_cast_bool() -> Fallible<()> {
    let lf_domain = LazyFrameDomain::new(vec![SeriesDomain::new(
        "bool",
        AtomDomain::<bool>::default(),
    )])?;
    let lf = df!(
        "bool" => &[true, true, false, false]
    )?
    .lazy();

    let casted = lf.clone().with_columns([
        col("bool").cast(DataType::String).alias("bool_String"),
        col("bool").cast(DataType::Float64).alias("bool_f64"),
        col("bool").cast(DataType::Int64).alias("bool_i64"),
    ]);
    let t_casted = make_stable_lazyframe(lf_domain, FrameDistance(SymmetricDistance), casted)?;

    let actual = t_casted.invoke(&lf)?.collect()?;
    let expected = df!(
        // repeat inputs
        "bool" => &[true, true, false, false],
        "bool_String" => &["true".to_string(), "true".to_string(), "false".to_string(), "false".to_string()],
        "bool_f64" => &[1.0f64, 1.0, 0.0, 0.0],
        "bool_i64" => &[1i64, 1, 0, 0],
    )?;
    assert_eq!(expected, actual);
    Ok(())
}

#[test]
fn test_make_expr_cast_output_dtype() -> Fallible<()> {
    let input_domain = LazyFrameDomain::new(vec![SeriesDomain::new(
        "value",
        AtomDomain::<f64>::default(),
    )])?;

    let categories = Categories::global();
    let enum_categories = FrozenCategories::new(["a", "b"].into_iter()).unwrap();
    for dtype in [
        DataType::Boolean,
        DataType::UInt32,
        DataType::UInt64,
        DataType::Int8,
        DataType::Int16,
        DataType::Int32,
        DataType::Int64,
        DataType::Float32,
        DataType::Float64,
        DataType::String,
        DataType::Date,
        DataType::Datetime(TimeUnit::Microseconds, None),
        DataType::Time,
        DataType::Categorical(categories.clone(), categories.mapping()),
        DataType::Enum(enum_categories.clone(), enum_categories.mapping().clone()),
        DataType::Array(Box::new(DataType::Float32), 2),
    ] {
        let cast = make_expr_cast(
            input_domain.clone().row_by_row(),
            FrameDistance(SymmetricDistance),
            col("value").cast(dtype.clone()),
        )?;

        assert_eq!(cast.output_domain.column.dtype(), dtype);
    }
    Ok(())
}

#[test]
fn test_make_expr_cast_categorical_to_integer_rejected() -> Fallible<()> {
    use crate::domains::CategoricalDomain;

    let input_domain = LazyFrameDomain::new(vec![SeriesDomain::new(
        "category",
        CategoricalDomain::default(),
    )])?;

    for dtype in [
        DataType::UInt8,
        DataType::UInt16,
        DataType::UInt32,
        DataType::UInt64,
        DataType::Int8,
        DataType::Int16,
        DataType::Int32,
        DataType::Int64,
    ] {
        let result = make_expr_cast(
            input_domain.clone().row_by_row(),
            FrameDistance(SymmetricDistance),
            col("category").cast(dtype),
        );
        assert!(result.is_err());
    }

    // Logical string values and fixed Enum codes remain safe.
    let categories = FrozenCategories::new(["A", "B"])?;
    for dtype in [
        DataType::String,
        DataType::Enum(categories.clone(), categories.mapping().clone()),
    ] {
        make_expr_cast(
            input_domain.clone().row_by_row(),
            FrameDistance(SymmetricDistance),
            col("category").cast(dtype),
        )?;
    }

    Ok(())
}

#[test]
fn test_make_expr_cast_nullability() -> Fallible<()> {
    // Non-strict casts can introduce nulls into otherwise non-nullable columns.
    let lf = df!("x" => &["1", "not-an-integer"])?.lazy();
    let input_domain = LazyFrameDomain::new(vec![SeriesDomain::new(
        "x",
        AtomDomain::<String>::default(),
    )])?;
    assert!(!input_domain.series_domains[0].nullable);

    // The constructor forces the default strict cast to be non-strict.
    let t_cast = make_expr_cast(
        input_domain.row_by_row(),
        FrameDistance(SymmetricDistance),
        col("x").cast(DataType::Int64),
    )?;
    assert!(t_cast.output_domain.column.nullable);

    let expr = t_cast.invoke(&lf.logical_plan)?.expr;
    let observed = lf.select([expr]).collect()?;
    assert_eq!(observed, df!("x" => &[Some(1_i64), None])?);
    assert!(
        t_cast
            .output_domain
            .column
            .member(observed.column("x")?.as_materialized_series())?
    );

    Ok(())
}

#[test]
fn test_make_expr_cast_widening_preserves_non_null() -> Fallible<()> {
    let lf = df!("x" => &[1i32, 2, 3])?.lazy();
    let input_domain =
        LazyFrameDomain::new(vec![SeriesDomain::new("x", AtomDomain::<i32>::default())])?;

    let t_cast = make_expr_cast(
        input_domain.row_by_row(),
        FrameDistance(SymmetricDistance),
        col("x").cast(DataType::Int64),
    )?;
    assert!(!t_cast.output_domain.column.nullable);

    let expr = t_cast.invoke(&lf.logical_plan)?.expr;
    let observed = lf.select([expr]).collect()?;
    assert_eq!(observed, df!("x" => &[1i64, 2, 3])?);
    assert!(
        t_cast
            .output_domain
            .column
            .member(observed.column("x")?.as_materialized_series())?
    );

    Ok(())
}

#[test]
fn test_make_expr_cast_other_null_preserving() -> Fallible<()> {
    let input_domain = LazyFrameDomain::new(vec![
        SeriesDomain::new("integer", AtomDomain::<i64>::default()),
        SeriesDomain::new("float", AtomDomain::<f32>::default()),
        SeriesDomain::new("bool", AtomDomain::<bool>::default()),
    ])?;

    for expr in [
        col("integer").cast(DataType::Float64),
        col("integer").cast(DataType::String),
        col("float").cast(DataType::Float64),
        col("bool").cast(DataType::String),
    ] {
        let t_cast = make_expr_cast(
            input_domain.clone().row_by_row(),
            FrameDistance(SymmetricDistance),
            expr,
        )?;
        assert!(!t_cast.output_domain.column.nullable);
    }

    Ok(())
}

use crate::core::Domain;
use crate::domains::{
    ArrayDomain, AtomDomain, CategoricalDomain, DatetimeDomain, LazyFrameDomain, SeriesDomain,
};
use crate::metrics::{FrameDistance, SymmetricDistance};
use crate::transformations::make_stable_lazyframe;

use super::*;

#[test]
fn test_make_expr_cast_string() -> Fallible<()> {
    let lf_domain = LazyFrameDomain::new(vec![SeriesDomain::new(
        "String",
        AtomDomain::<String>::default(),
    )])?;
    let lf = df!(
        "String" => &["A".to_string(), "3.14".to_string(), "1e300".to_string(), "NaN".to_string()],
    )?
    .lazy();

    let casted = lf.clone().with_columns([
        col("String").cast(DataType::Float64).alias("String_f64"),
        col("String").cast(DataType::Int64).alias("String_i64"),
        // Polars doesn't support casting a string to a boolean
        // col("String").cast(DataType::Boolean).alias("String_bool"),
    ]);
    let t_casted = make_stable_lazyframe(lf_domain, FrameDistance(SymmetricDistance), casted)?;

    let actual = t_casted.invoke(&lf)?.collect()?;
    let expected = df!(
        // repeat inputs
        "String" => &["A".to_string(), "3.14".to_string(), "1e300".to_string(), "NaN".to_string()],

        // string -> int casts can go to null and nan
        "String_f64" => &[None, Some(3.14), Some(1e300), Some(f64::NAN)],
        // No value is exactly integer, so all are None
        "String_i64" => &[None::<i64>, None, None, None],
        // non-strict casting still fails, but fails in a data-independent way
        // "String_bool" => &[],
    )?;
    assert_eq!(expected, actual);
    Ok(())
}

#[test]
fn test_make_expr_cast_f64() -> Fallible<()> {
    let lf_domain =
        LazyFrameDomain::new(vec![SeriesDomain::new("f64", AtomDomain::<f64>::default())])?;
    let lf = df!(
        "f64" => &[f64::NAN, 1., 1.0e300, -1.],
    )?
    .lazy();

    let casted = lf.clone().with_columns([
        col("f64").cast(DataType::String).alias("f64_String"),
        col("f64").cast(DataType::Int64).alias("f64_i64"),
        col("f64").cast(DataType::Boolean).alias("f64_bool"),
    ]);
    let t_casted = make_stable_lazyframe(lf_domain, FrameDistance(SymmetricDistance), casted)?;

    let actual = t_casted.invoke(&lf)?.collect()?;
    let expected = df!(
        // repeat inputs
        "f64" => &[f64::NAN, 1., 1e300, -1.],
        "f64_String" => &["NaN".to_string(), "1.0".to_string(), "1e300".to_string(), "-1.0".to_string()],
        "f64_i64" => &[None, Some(1), None, Some(-1)],
        // NaN is considered truth-y
        "f64_bool" => &[true, true, true, true],
    )?;
    assert_eq!(expected, actual);
    Ok(())
}

#[test]
fn test_make_expr_cast_int() -> Fallible<()> {
    let lf_domain =
        LazyFrameDomain::new(vec![SeriesDomain::new("i64", AtomDomain::<i64>::default())])?;
    let lf = df!(
        "i64" => &[i64::MAX, i64::MIN, 0, 1],
    )?
    .lazy();

    let casted = lf.clone().with_columns([
        col("i64").cast(DataType::String).alias("i64_String"),
        col("i64").cast(DataType::Float64).alias("i64_f64"),
        col("i64").cast(DataType::Boolean).alias("i64_bool"),
    ]);
    let t_casted = make_stable_lazyframe(lf_domain, FrameDistance(SymmetricDistance), casted)?;

    let actual = t_casted.invoke(&lf)?.collect()?;
    let expected = df!(
        // repeat inputs
        "i64" => &[i64::MAX, i64::MIN, 0, 1],
        "i64_String" => &["9223372036854775807".to_string(), "-9223372036854775808".to_string(), "0".to_string(), "1".to_string()],
        "i64_f64" => &[i64::MAX as f64, i64::MIN as f64, 0.0, 1.0],
        "i64_bool" => &[true, true, false, true],
    )?;
    assert_eq!(expected, actual);
    Ok(())
}

#[test]
fn test_make_expr_cast_bool() -> Fallible<()> {
    let lf_domain = LazyFrameDomain::new(vec![SeriesDomain::new(
        "bool",
        AtomDomain::<bool>::default(),
    )])?;
    let lf = df!(
        "bool" => &[true, true, false, false]
    )?
    .lazy();

    let casted = lf.clone().with_columns([
        col("bool").cast(DataType::String).alias("bool_String"),
        col("bool").cast(DataType::Float64).alias("bool_f64"),
        col("bool").cast(DataType::Int64).alias("bool_i64"),
    ]);
    let t_casted = make_stable_lazyframe(lf_domain, FrameDistance(SymmetricDistance), casted)?;

    let actual = t_casted.invoke(&lf)?.collect()?;
    let expected = df!(
        // repeat inputs
        "bool" => &[true, true, false, false],
        "bool_String" => &["true".to_string(), "true".to_string(), "false".to_string(), "false".to_string()],
        "bool_f64" => &[1.0f64, 1.0, 0.0, 0.0],
        "bool_i64" => &[1i64, 1, 0, 0],
    )?;
    assert_eq!(expected, actual);
    Ok(())
}

#[test]
fn test_make_expr_cast_output_dtype() -> Fallible<()> {
    let input_domain = LazyFrameDomain::new(vec![SeriesDomain::new(
        "value",
        AtomDomain::<f64>::default(),
    )])?;

    for dtype in [
        DataType::Boolean,
        DataType::UInt32,
        DataType::UInt64,
        DataType::Int8,
        DataType::Int16,
        DataType::Int32,
        DataType::Int64,
        DataType::Float32,
        DataType::Float64,
        DataType::String,
    ] {
        let cast = make_expr_cast(
            input_domain.clone().row_by_row(),
            FrameDistance(SymmetricDistance),
            col("value").cast(dtype.clone()),
        )?;

        assert_eq!(cast.output_domain.column.dtype(), dtype);
    }

    // The dtype classifier does not certify cross-temporal conversions or
    // arbitrary primitive-to-enum conversions.
    let enum_categories = FrozenCategories::new(["a", "b"])?;
    for dtype in [
        DataType::Datetime(TimeUnit::Microseconds, None),
        DataType::Time,
        DataType::Enum(enum_categories.clone(), enum_categories.mapping().clone()),
    ] {
        assert!(
            make_expr_cast(
                input_domain.clone().row_by_row(),
                FrameDistance(SymmetricDistance),
                col("value").cast(dtype.clone()),
            )
            .is_err(),
            "{dtype:?}"
        );
    }
    Ok(())
}

#[test]
fn test_make_expr_cast_rejects_unsafe_categorical() -> Fallible<()> {
    let input_domain = LazyFrameDomain::new(vec![
        SeriesDomain::new("name", AtomDomain::<String>::default()),
        SeriesDomain::new("code", AtomDomain::<u32>::default()),
        SeriesDomain::new("category", CategoricalDomain::default()),
    ])?;
    let categories = Categories::global();
    let categorical = DataType::Categorical(categories.clone(), categories.mapping());
    let other = Categories::random("".into(), CategoricalPhysical::U32);
    let other_categorical = DataType::Categorical(other.clone(), other.mapping());

    for (column, to) in [
        ("category", DataType::UInt32),
        ("category", DataType::Float64),
        ("name", categorical.clone()),
        ("category", other_categorical),
    ] {
        assert!(
            make_expr_cast(
                input_domain.clone().row_by_row(),
                FrameDistance(SymmetricDistance),
                col(column).cast(to.clone()),
            )
            .is_err(),
            "{column} -> {to}"
        );
    }

    // Identity, logical String/Enum, and String -> fixed Enum are supported.
    let enum_categories = FrozenCategories::new(["A", "B"])?;
    let fixed_enum = DataType::Enum(enum_categories.clone(), enum_categories.mapping().clone());
    for (column, to) in [
        ("category", categorical),
        ("category", DataType::String),
        ("category", fixed_enum.clone()),
        ("name", fixed_enum),
    ] {
        make_expr_cast(
            input_domain.clone().row_by_row(),
            FrameDistance(SymmetricDistance),
            col(column).cast(to),
        )?;
    }

    Ok(())
}

#[test]
fn test_make_expr_cast_temporal_safety() -> Fallible<()> {
    // Check the constructor boundary as well as the shared cast classifier.
    let input_domain = LazyFrameDomain::new(vec![
        SeriesDomain::new("text", AtomDomain::<String>::default()),
        SeriesDomain::new(
            "timestamp",
            DatetimeDomain {
                time_unit: TimeUnit::Microseconds,
                time_zone: None,
            },
        ),
    ])?;
    for (column, to) in [
        ("text", DataType::Datetime(TimeUnit::Nanoseconds, None)),
        ("timestamp", DataType::String),
    ] {
        assert!(
            make_expr_cast(
                input_domain.clone().row_by_row(),
                FrameDistance(SymmetricDistance),
                col(column).cast(to),
            )
            .is_err(),
            "{column}"
        );
    }
    Ok(())
}

#[test]
fn test_make_expr_cast_rejects_all_array_casts() -> Fallible<()> {
    let input_domain = LazyFrameDomain::new(vec![
        SeriesDomain::new("array", ArrayDomain::new(AtomDomain::<i32>::default(), 2)),
        SeriesDomain::new("scalar", AtomDomain::<i32>::default()),
    ])?;

    for (column, to) in [
        ("array", DataType::String),
        ("scalar", DataType::Array(Box::new(DataType::Int32), 2)),
    ] {
        assert!(
            make_expr_cast(
                input_domain.clone().row_by_row(),
                FrameDistance(SymmetricDistance),
                col(column).cast(to.clone()),
            )
            .is_err(),
            "{column} -> {to}"
        );
    }
    Ok(())
}

#[test]
fn test_make_expr_cast_nullability() -> Fallible<()> {
    // Non-strict casts can introduce nulls into otherwise non-nullable columns.
    let lf = df!("x" => &["1", "not-an-integer"])?.lazy();
    let input_domain = LazyFrameDomain::new(vec![SeriesDomain::new(
        "x",
        AtomDomain::<String>::default(),
    )])?;
    assert!(!input_domain.series_domains[0].nullable);

    // The constructor forces the default strict cast to be non-strict.
    let t_cast = make_expr_cast(
        input_domain.clone().row_by_row(),
        FrameDistance(SymmetricDistance),
        col("x").cast(DataType::Int64),
    )?;
    assert!(t_cast.output_domain.column.nullable);

    let expr = t_cast.invoke(&lf.logical_plan)?.expr;
    let observed = lf.select([expr]).collect()?;
    assert_eq!(observed, df!("x" => &[Some(1_i64), None])?);
    assert!(
        t_cast
            .output_domain
            .column
            .member(observed.column("x")?.as_materialized_series())?
    );

    // Wrapping is opt-in and is not certified for private values.
    assert!(
        make_expr_cast(
            input_domain.row_by_row(),
            FrameDistance(SymmetricDistance),
            col("x").cast_with_options(DataType::Int64, CastOptions::Overflowing),
        )
        .is_err()
    );

    Ok(())
}

#[test]
fn test_make_expr_cast_widening_preserves_non_null() -> Fallible<()> {
    let lf = df!("x" => &[1i32, 2, 3])?.lazy();
    let input_domain =
        LazyFrameDomain::new(vec![SeriesDomain::new("x", AtomDomain::<i32>::default())])?;

    let t_cast = make_expr_cast(
        input_domain.row_by_row(),
        FrameDistance(SymmetricDistance),
        col("x").cast(DataType::Int64),
    )?;
    assert!(!t_cast.output_domain.column.nullable);

    let expr = t_cast.invoke(&lf.logical_plan)?.expr;
    let observed = lf.select([expr]).collect()?;
    assert_eq!(observed, df!("x" => &[1i64, 2, 3])?);
    assert!(
        t_cast
            .output_domain
            .column
            .member(observed.column("x")?.as_materialized_series())?
    );

    Ok(())
}

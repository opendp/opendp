use crate::core::Domain;
use crate::domains::{
    ArrayDomain, AtomDomain, EnumDomain, LazyFrameDomain, OptionDomain, SeriesDomain,
};
use crate::metrics::{FrameDistance, SymmetricDistance};
use core::f64;
use polars_plan::plans::typed_lit;
use std::ops::{Add, Div, Mul, Rem, Sub};

use super::*;

fn get_f64_data() -> Fallible<(LazyFrameDomain, LazyFrame)> {
    let lf_domain = LazyFrameDomain::new(vec![
        SeriesDomain::new("L", AtomDomain::<f64>::default()),
        SeriesDomain::new("R", OptionDomain::new(AtomDomain::<f64>::default())),
    ])?;

    let lf = df!(
        "L" => [
            Some(0.), Some(1.),
            Some(f64::NAN), Some(0.),
            None, Some(0.),
            Some(f64::INFINITY), Some(0.)
        ],
        "R" => [
            Some(0.), Some(0.),
            Some(f64::NAN), Some(f64::NAN),
            None, None,
            Some(f64::INFINITY), Some(f64::INFINITY)
        ],
    )?
    .lazy();

    Ok((lf_domain, lf))
}

fn get_i32_data() -> Fallible<(LazyFrameDomain, LazyFrame)> {
    let lf_domain = LazyFrameDomain::new(vec![
        SeriesDomain::new("L", AtomDomain::<i32>::default()),
        SeriesDomain::new("R", OptionDomain::new(AtomDomain::<i32>::default())),
    ])?;

    let lf = df!(
        "L" => [Some(1), Some(1), Some(1)],
        "R" => [Some(0), Some(1), None],
    )?
    .lazy();

    Ok((lf_domain, lf))
}

fn get_bool_data() -> Fallible<(LazyFrameDomain, LazyFrame)> {
    let lf_domain = LazyFrameDomain::new(vec![
        SeriesDomain::new("L", AtomDomain::<bool>::default()),
        SeriesDomain::new("R", OptionDomain::new(AtomDomain::<bool>::default())),
    ])?;

    let lf = df!(
        "L" => [
            Some(true), Some(true), Some(false), Some(false),
            Some(true), None, Some(false), None, None
        ],
        "R" => [
            Some(true), Some(false), Some(true), Some(false),
            None, Some(true), None, Some(false), None
        ],
    )?
    .lazy();

    Ok((lf_domain, lf))
}

fn get_string_data() -> Fallible<(LazyFrameDomain, LazyFrame)> {
    let lf_domain = LazyFrameDomain::new(vec![
        SeriesDomain::new("L", AtomDomain::<String>::default()),
        SeriesDomain::new("R", OptionDomain::new(AtomDomain::<String>::default())),
    ])?;

    let lf = df!(
        "L" => ["".to_string(), "A".to_string()],
        "R" => [Some("1".to_string()), None],
    )?
    .lazy();

    Ok((lf_domain, lf))
}

macro_rules! test_binary {
    // (the function to call to get the data, the operation to test, the expected data output)
    ($get:ident, $op:ident, $expected:expr) => {{
        let (lf_domain, lf) = $get()?;
        let expr_domain = lf_domain.row_by_row();
        assert_eq!(
            lf.clone()
                .with_column(col("L").$op(col("R")))
                .collect()?
                .column("L")?,
            &Column::new("L".into(), $expected),
            "input: {:?}",
            lf.clone()
                .with_columns([col("L").$op(col("R")).alias("O")])
                .collect()?
        );
        let t_op = col("L")
            .$op(col("R"))
            .make_stable(expr_domain.clone(), FrameDistance(SymmetricDistance))?;
        let output_series = &t_op.output_domain.column;
        assert_eq!(&*output_series.name, "L");

        let out = lf
            .select([col("L").$op(col("R")).alias("out").null_count()])
            .collect()?
            .column("out")?
            .u32()?
            .get(0)
            .unwrap();

        assert_eq!(output_series.nullable, (out > 0));
        Fallible::Ok(())
    }};
}

#[test]
fn test_eq() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        eq,
        [
            Some(true),
            Some(false),
            // NaN is equal to NaN: https://docs.pola.rs/user-guide/concepts/data-types-and-structures/#floating-point-numbers
            Some(true),
            Some(false),
            None,
            None,
            Some(true),
            Some(false),
        ]
    )
}

#[test]
fn test_eq_missing() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        eq_missing,
        [
            true,
            false, // NaN is equal to NaN: https://docs.pola.rs/user-guide/concepts/data-types-and-structures/#floating-point-numbers
            true, false, true, false, true, false,
        ]
    )
}

#[test]
fn test_neq() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        neq,
        [
            Some(false),
            Some(true),
            Some(false),
            Some(true),
            None,
            None,
            Some(false),
            Some(true),
        ]
    )
}

#[test]
fn test_neq_validity() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        neq_missing,
        [false, true, false, true, false, true, false, true,]
    )
}

#[test]
fn test_lt() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        lt,
        [
            Some(false),
            Some(false),
            // zero is less than NaN?!
            Some(false),
            Some(true),
            None,
            None,
            Some(false),
            Some(true),
        ]
    )
}

#[test]
fn test_lt_eq() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        lt_eq,
        [
            Some(true),
            Some(false),
            // nan is equal to NaN, zero is lte NaN: https://docs.pola.rs/user-guide/concepts/data-types-and-structures/#floating-point-numbers
            Some(true),
            Some(true),
            None,
            None,
            Some(true),
            Some(true),
        ]
    )
}

#[test]
fn test_gt() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        gt,
        [
            Some(false),
            Some(true),
            Some(false),
            Some(false),
            None,
            None,
            Some(false),
            Some(false),
        ]
    )
}

#[test]
fn test_gt_eq() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        gt_eq,
        [
            Some(true),
            Some(true),
            // nan is equal to NaN: https://docs.pola.rs/user-guide/concepts/data-types-and-structures/#floating-point-numbers
            Some(true),
            Some(false),
            None,
            None,
            Some(true),
            Some(false),
        ]
    )
}

#[test]
fn test_and() -> Fallible<()> {
    test_binary!(
        get_bool_data,
        and,
        [
            Some(true),
            Some(false),
            Some(false),
            Some(false),
            None,
            None,
            Some(false),
            Some(false),
            None,
        ]
    )
}

#[test]
fn test_or() -> Fallible<()> {
    test_binary!(
        get_bool_data,
        or,
        [
            Some(true),
            Some(true),
            Some(true),
            Some(false),
            Some(true),
            Some(true),
            None,
            None,
            None,
        ]
    )
}

#[test]
fn test_logical_and() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        logical_and,
        [
            Some(false),
            Some(false),
            // nan is truth-y
            Some(true),
            Some(false),
            None,
            Some(false),
            Some(true),
            Some(false)
        ]
    )
}

#[test]
fn test_logical_or() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        logical_or,
        [
            Some(false),
            Some(true),
            // nan is truth-y
            Some(true),
            Some(true),
            None,
            None,
            Some(true),
            Some(true)
        ]
    )
}

#[test]
fn test_xor() -> Fallible<()> {
    test_binary!(
        get_bool_data,
        xor,
        [
            Some(false),
            Some(true),
            Some(true),
            Some(false),
            // why not same behavior as or?
            None,
            None,
            None,
            None,
            None,
        ]
    )
}

#[test]
fn test_add() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        add,
        [
            Some(0.),
            Some(1.),
            Some(f64::NAN),
            Some(f64::NAN),
            None,
            None,
            Some(f64::INFINITY),
            Some(f64::INFINITY)
        ]
    )?;
    test_binary!(get_i32_data, add, [Some(1), Some(2), None])?;
    test_binary!(get_string_data, add, [Some("1".to_string()), None])?;
    Ok(())
}

#[test]
fn test_sub() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        sub,
        [
            Some(0.),
            Some(1.),
            Some(f64::NAN),
            Some(f64::NAN),
            None,
            None,
            Some(f64::NAN),
            Some(-f64::INFINITY)
        ]
    )?;
    test_binary!(get_i32_data, sub, [Some(1), Some(0), None])?;
    Ok(())
}

#[test]
fn test_mul() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        mul,
        [
            Some(0.),
            Some(0.),
            Some(f64::NAN),
            Some(f64::NAN),
            None,
            None,
            Some(f64::INFINITY),
            Some(f64::NAN)
        ]
    )?;
    test_binary!(get_i32_data, mul, [Some(0), Some(1), None])?;
    Ok(())
}

#[test]
fn test_div() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        div,
        [
            Some(f64::NAN),
            Some(f64::INFINITY),
            Some(f64::NAN),
            Some(f64::NAN),
            None,
            None,
            Some(f64::NAN),
            Some(0.)
        ]
    )?;
    test_binary!(get_i32_data, div, [None, Some(1), None])?;
    Ok(())
}

#[test]
fn test_floor_div() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        floor_div,
        [
            Some(f64::NAN),
            Some(f64::INFINITY),
            Some(f64::NAN),
            Some(f64::NAN),
            None,
            None,
            Some(f64::NAN),
            Some(0.)
        ]
    )?;
    test_binary!(get_i32_data, floor_div, [None, Some(1), None])?;
    Ok(())
}

#[test]
fn test_rem() -> Fallible<()> {
    test_binary!(
        get_f64_data,
        rem,
        [
            Some(f64::NAN),
            Some(f64::NAN),
            Some(f64::NAN),
            Some(f64::NAN),
            None,
            None,
            Some(f64::NAN),
            Some(f64::NAN)
        ]
    )?;
    test_binary!(get_i32_data, rem, [None, Some(0), None])?;

    // A zero divisor can produce null even if neither input column is nullable.
    let lf_domain = LazyFrameDomain::new(vec![
        SeriesDomain::new("L", AtomDomain::<i32>::default()),
        SeriesDomain::new("R", AtomDomain::<i32>::default()),
    ])?;
    let t_rem = col("L")
        .rem(col("R"))
        .make_stable(lf_domain.row_by_row(), FrameDistance(SymmetricDistance))?;
    assert!(t_rem.output_domain.column.nullable);
    Ok(())
}

#[test]
fn test_overflow() -> Fallible<()> {
    // ensures behavior of arithmetic is as expected when overflow occurs
    let data = df!(
        "x" => [i32::MAX, i32::MIN],
        "add" => [1, -1],
        "sub" => [-1, 1],
        "mul" => [2, 2],
    )?;
    let expected = df!(
        "add" => [i32::MIN, i32::MAX],
        "sub" => [i32::MIN, i32::MAX],
        "mul" => [-2, 0],
    )?;
    let observed = data
        .lazy()
        .select([
            (col("x") + col("add")).alias("add"),
            (col("x") - col("sub")).alias("sub"),
            (col("x") * col("mul")).alias("mul"),
        ])
        .collect()?;
    assert_eq!(observed, expected);
    Ok(())
}

#[test]
fn test_enum_string_ordering_is_not_stable() -> Fallible<()> {
    let enum_domain = EnumDomain::new(Series::new("".into(), vec!["low", "high"]))?;
    let domain = LazyFrameDomain::new(vec![
        SeriesDomain::new("E", enum_domain.clone()),
        SeriesDomain::new("S", AtomDomain::<String>::default()),
        SeriesDomain::new("E2", enum_domain),
    ])?;

    // Polars can fail when a private string is not one of the enum's categories.
    for expr in [
        col("E").lt(col("S")),
        col("E").lt_eq(col("S")),
        col("E").gt(col("S")),
        col("E").gt_eq(col("S")),
        col("S").lt(col("E")),
        col("S").lt_eq(col("E")),
        col("S").gt(col("E")),
        col("S").gt_eq(col("E")),
    ] {
        let result = make_expr_binary(
            domain.clone().row_by_row(),
            FrameDistance(SymmetricDistance),
            expr,
        );
        assert!(result.is_err());
    }

    // Equality and ordering between compatible enum columns remain supported.
    for expr in [
        col("E").eq(col("S")),
        col("S").eq(col("E")),
        col("E").lt(col("E2")),
        col("S").lt(col("S")),
    ] {
        make_expr_binary(
            domain.clone().row_by_row(),
            FrameDistance(SymmetricDistance),
            expr,
        )?;
    }
    Ok(())
}

#[test]
fn test_enum_string_equality_with_unknown_categories() -> Fallible<()> {
    let enum_domain = EnumDomain::new(Series::new("".into(), vec!["low", "high"]))?;
    let enum_dtype = SeriesDomain::new("E", enum_domain.clone()).dtype();
    let domain = LazyFrameDomain::new(vec![
        SeriesDomain::new("E", enum_domain),
        SeriesDomain::new("S", AtomDomain::<String>::default()),
    ])?;
    let lf = df!(
        "E" => ["low", "high", "low"],
        "S" => ["low", "unknown", "high"],
    )?
    .lazy()
    .with_column(col("E").cast(enum_dtype));

    // Unlike ordering, equality with an unknown enum category does not fail.
    for (expr, expected) in [
        (col("E").eq(col("S")), [true, false, false]),
        (col("S").eq(col("E")), [true, false, false]),
        (col("E").neq(col("S")), [false, true, true]),
        (col("S").neq(col("E")), [false, true, true]),
        (col("E").eq_missing(col("S")), [true, false, false]),
        (col("S").eq_missing(col("E")), [true, false, false]),
        (col("E").neq_missing(col("S")), [false, true, true]),
        (col("S").neq_missing(col("E")), [false, true, true]),
    ] {
        expr.clone().make_stable(
            domain.clone().row_by_row(),
            FrameDistance(SymmetricDistance),
        )?;
        let observed = lf.clone().select([expr.alias("out")]).collect()?;
        assert_eq!(
            observed.column("out")?,
            &Column::new("out".into(), expected)
        );
    }
    Ok(())
}

#[test]
fn test_binary_rejects_arrays() -> Fallible<()> {
    let domain = LazyFrameDomain::new(vec![
        SeriesDomain::new("array", ArrayDomain::new(AtomDomain::<i32>::default(), 2)),
        SeriesDomain::new("value", AtomDomain::<i32>::default()),
    ])?
    .row_by_row();

    for expr in [
        col("array") + col("array"),
        col("array") + col("value"),
        col("value") + col("array"),
        col("array").eq(col("array")),
        col("array").lt(col("array")),
    ] {
        assert!(
            expr.clone()
                .make_stable(domain.clone(), FrameDistance(SymmetricDistance))
                .is_err(),
            "{expr:?}"
        );
    }
    Ok(())
}

#[test]
fn test_binary_rejects_unvalidated_implicit_coercion() -> Fallible<()> {
    let domain = LazyFrameDomain::new(vec![
        SeriesDomain::new(
            "enum_a",
            EnumDomain::new(Series::new("".into(), vec!["a", "b"]))?,
        ),
        SeriesDomain::new(
            "enum_b",
            EnumDomain::new(Series::new("".into(), vec!["b", "c"]))?,
        ),
        SeriesDomain::new("text", AtomDomain::<String>::default()),
        SeriesDomain::new("number", AtomDomain::<i64>::default()),
    ])?
    .row_by_row();

    for expr in [
        col("enum_a").eq(col("enum_b")),
        col("enum_a").eq(col("number")),
        col("text").eq(col("number")),
    ] {
        assert!(
            expr.clone()
                .make_stable(domain.clone(), FrameDistance(SymmetricDistance))
                .is_err(),
            "{expr:?}"
        );
    }
    Ok(())
}

#[test]
fn test_mixed_temporal_comparisons_are_rejected() -> Fallible<()> {
    let nanoseconds = DataType::Datetime(TimeUnit::Nanoseconds, None);
    // Year 3000 fits in Date and Datetime(ms/us), but not Datetime(ns).
    let inputs = [
        Series::new(
            "us".into(),
            [1_577_836_800_000_000_i64, 32_503_680_000_000_000_i64],
        )
        .cast(&DataType::Datetime(TimeUnit::Microseconds, None))?,
        Series::new("ms".into(), [1_577_836_800_000_i64, 32_503_680_000_000_i64])
            .cast(&DataType::Datetime(TimeUnit::Milliseconds, None))?,
        Series::new("date".into(), [18_262_i32, 376_200_i32]).cast(&DataType::Date)?,
    ];

    for input in inputs {
        let name = input.name().clone();
        let mut input_domain =
            SeriesDomain::new_from_field(Field::new(name.clone(), input.dtype().clone()))?;
        input_domain.nullable = false;
        let mut ns_domain =
            SeriesDomain::new_from_field(Field::new("ns".into(), nanoseconds.clone()))?;
        ns_domain.nullable = false;
        let domain = LazyFrameDomain::new(vec![input_domain, ns_domain])?.row_by_row();

        for expr in [
            col(name.clone()).eq(col("ns")),
            col(name.clone()).eq_missing(col("ns")),
            col(name.clone()).lt(col("ns")),
        ] {
            assert!(
                expr.make_stable(domain.clone(), FrameDistance(SymmetricDistance))
                    .is_err(),
                "{name}"
            );
        }

        // Cross-temporal casts also require a separate safety proof.
        let expr = col(name.clone()).cast(nanoseconds.clone()).eq(col("ns"));
        assert!(
            expr.make_stable(domain, FrameDistance(SymmetricDistance))
                .is_err(),
            "{name}"
        );
    }
    Ok(())
}

#[test]
fn test_same_type_temporal_comparisons_remain_supported() -> Fallible<()> {
    for dtype in [
        DataType::Date,
        DataType::Datetime(TimeUnit::Nanoseconds, None),
        DataType::Time,
    ] {
        let mut left = SeriesDomain::new_from_field(Field::new("L".into(), dtype.clone()))?;
        left.nullable = false;
        let mut right = SeriesDomain::new_from_field(Field::new("R".into(), dtype.clone()))?;
        right.nullable = false;
        let domain = LazyFrameDomain::new(vec![left, right])?.row_by_row();

        for expr in [
            col("L").eq(col("R")),
            col("L").neq(col("R")),
            col("L").lt(col("R")),
            col("L").eq_missing(col("R")),
        ] {
            let t = expr.make_stable(domain.clone(), FrameDistance(SymmetricDistance))?;
            assert!(!t.output_domain.column.nullable, "{dtype}");
        }
        assert!(
            (col("L") + col("R"))
                .make_stable(domain, FrameDistance(SymmetricDistance))
                .is_err(),
            "{dtype}"
        );
    }
    Ok(())
}

#[test]
fn test_numeric_binary_coercion_matches_optimized_polars() -> Fallible<()> {
    // Include mixed signed/unsigned boundaries, float extremes, NaNs, and nulls.
    // Verify the certified domain against the values and dtype that Polars
    // actually produces after its implicit casts and optimizer rewrites.
    let cases = [
        (
            Series::new("L".into(), [i64::MIN, i64::MAX, -1, 0]),
            Series::new("R".into(), [u64::MAX, u64::MAX, 0, 1]),
        ),
        (
            Series::new("L".into(), [0u64, 1, u64::MAX, u64::MAX]),
            Series::new("R".into(), [i64::MIN, i64::MAX, -1, 0]),
        ),
        (
            Series::new("L".into(), [u32::MAX, 0, 42, 1]),
            Series::new("R".into(), [-1i64, i64::MAX, i64::MIN, 0]),
        ),
        (
            Series::new("L".into(), [f32::MIN, f32::MAX, f32::NAN, f32::INFINITY]),
            Series::new("R".into(), [f64::MAX, -f64::MAX, f64::NAN, f64::INFINITY]),
        ),
        (
            Series::new("L".into(), [Some(i64::MAX), None, Some(-1), Some(0)]),
            Series::new("R".into(), [Some(u64::MAX), Some(0), None, Some(1)]),
        ),
        (
            Series::new(
                "L".into(),
                [Some(f32::MAX), None, Some(f32::MIN), Some(0.0)],
            ),
            Series::new(
                "R".into(),
                [Some(f64::MAX), Some(0.0), None, Some(f64::MIN)],
            ),
        ),
    ];

    for (left, right) in cases {
        let mut left_domain =
            SeriesDomain::new_from_field(Field::new("L".into(), left.dtype().clone()))?;
        left_domain.nullable = left.has_nulls();
        let mut right_domain =
            SeriesDomain::new_from_field(Field::new("R".into(), right.dtype().clone()))?;
        right_domain.nullable = right.has_nulls();
        let domain = LazyFrameDomain::new(vec![left_domain, right_domain])?.row_by_row();
        let lf = DataFrame::new(vec![left.into_column(), right.into_column()])?.lazy();

        for expr in [
            col("L") + col("R"),
            col("L").eq(col("R")),
            col("L").eq_missing(col("R")),
        ] {
            let t = expr
                .clone()
                .make_stable(domain.clone(), FrameDistance(SymmetricDistance))?;
            let expected = lf.clone().select([expr.clone()]).collect()?;
            let observed = lf
                .clone()
                .select([t.invoke(&lf.logical_plan)?.expr])
                .collect()?;
            assert_eq!(observed, expected, "{expr:?}");
            let output = expected.get_columns()[0].as_materialized_series();
            assert_eq!(
                t.output_domain.column.dtype(),
                output.dtype().clone(),
                "{expr:?}"
            );
            assert!(t.output_domain.column.member(output)?, "{expr:?}");
            assert!(
                t.output_domain.column.nullable || !output.has_nulls(),
                "{expr:?}"
            );
        }
    }
    Ok(())
}

#[test]
fn test_numeric_dynamic_literal_coercion_matches_optimized_polars() -> Fallible<()> {
    let domain = LazyFrameDomain::new(vec![SeriesDomain::new(
        "x",
        OptionDomain::new(AtomDomain::<f32>::default()),
    )])?
    .row_by_row();
    let lf = df!("x" => [Some(f32::MAX), None, Some(f32::MIN), Some(0.0f32)])?.lazy();

    for expr in [
        col("x") + lit(0.5f64),
        col("x") + typed_lit(0.5f64),
        lit(0.5f64) + col("x"),
        col("x") + lit(1i32),
        col("x") + typed_lit(1i32),
        col("x") + lit(f64::MAX),
        col("x") + typed_lit(f64::MAX),
        lit(f64::MAX) + col("x"),
        col("x") + lit(i64::MAX),
        col("x") + typed_lit(u64::MAX),
        col("x").eq(typed_lit(f64::MAX)),
        col("x").eq_missing(lit(f64::MAX)),
    ] {
        let t = expr
            .clone()
            .make_stable(domain.clone(), FrameDistance(SymmetricDistance))?;
        let expected = lf.clone().select([expr.clone()]).collect()?;
        let observed = lf
            .clone()
            .select([t.invoke(&lf.logical_plan)?.expr])
            .collect()?;
        assert_eq!(observed, expected, "{expr:?}");
        let output = expected.get_columns()[0].as_materialized_series();
        assert_eq!(
            t.output_domain.column.dtype(),
            output.dtype().clone(),
            "{expr:?}"
        );
        assert!(t.output_domain.column.member(output)?, "{expr:?}");
        assert!(
            t.output_domain.column.nullable || !output.has_nulls(),
            "{expr:?}"
        );
    }
    Ok(())
}
